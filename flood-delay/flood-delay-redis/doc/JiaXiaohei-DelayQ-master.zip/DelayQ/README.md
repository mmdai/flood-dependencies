# DelayQ 
[![License](https://img.shields.io/badge/license-Apache%20License%202.0-blue.svg)](https://gitee.com/JiaXiaohei/DelayQ/blob/master/LICENSE)

#### 介绍
基于 Redis & 数据库 的延时队列中间件，采用 Java 开发，支持延时调用 RESTful 服务。

参考 [有赞延迟队列设计](http://tech.youzan.com/queuing_delay) 中的部分设计进行的设计和实现。

![首页](image/index.png)


#### 软件架构
* Job Pool用来存放所有Job的元信息。
* Delay Bucket是十组以时间为维度的有序队列，以Job Id判定存入指定Bucket，用来存放所有需要延时的Job Id。
* Timer负责实时扫描各个Bucket，并将delay时间大于等于当前时间的Job放入到对应的Ready Queue。
* Ready Queue按照任务的类型(Topic)执行相关操作，完成后将任务状态回写进Job Pool。

![架构](image/framework.png)


#### 环境依赖

* Java 1.8+
* Redis
* 数据库(使用PostgreSQL开发，理论上兼容Oracle、Mysql、MariaDB)

#### 使用说明
##### 部署项目
* 创建表
```
-- PostgreSQL
CREATE TABLE tb_delayq_job (
	id int8 NOT NULL,
	topic varchar(50) NULL,
	delay int4 NULL,
	ttr int4 NULL,
	body varchar(1000) NULL,
	status varchar(10) NULL,
	execution_time int8 NULL,
	create_time int8 NULL,
	CONSTRAINT pk_tb_delayq_job_id PRIMARY KEY (id)
);

-- Oracle
CREATE TABLE tb_delayq_job (
	id NUMBER(18) NOT NULL,
	topic VARCHAR2(50) NULL,
	delay NUMBER(8) NULL,
	ttr NUMBER(8) NULL,
	body VARCHAR2(1000) NULL,
	status VARCHAR2(10) NULL,
	execution_time NUMBER(20) NULL,
	create_time NUMBER(20) NULL,
	CONSTRAINT pk_tb_delayq_job_id PRIMARY KEY (id)
);
```
* 修改application-dev.yml配置文件
* 执行./startup.sh 或 java -jar DelayQ.jar --spring.profiles.active=dev
* 访问 http://localhost:16996/delay-q/index 查看任务列表

##### 创建任务
* 发起Post请求
```
URL：
http://172.16.6.202:16996/delay-q/add?topic=任务类型&delay=等待时间&ttr=超时时间
```
Post Param

| 参数名 | 名称 | 必填 | 参考 | 备注 | 
| ---- | ---- | ---- | ---- | ---- |
| topic | 任务类型 | 是 | HttpPostTask | 目前只支持发起Post请求 |
| delay | 等待时间 | 是 | 60 | 单位(s) |
| ttr | 超时时间 | 是 | 10 | 单位(s) |

Post Body

| 参数名 | 名称 | 必填 | 参考 | 备注 | 
| ---- | ---- | ---- | ---- | ---- |
| url | 远端服务URL | 是 | |  |
| headers | 头文件 | 否 | |  |
| body | PostBody | 否 | |  |
| passrule | 任务通过规则 | | "code": "1" | 通过识别远端服务返回值 来确认任务是否成功 |

```json
{
    "url": "http://172.16.6.202:16996/delay-q/add?topic=PrintTask&delay=10&ttr=10",
    "headers": {
        "Content-Type": "application/json"
    },
    "body": "",
    "passrule": {
        "code": "1"
    }
}
```
![PostTask](image/PostTask.png)


#### 参与贡献

1.  Fork 本仓库
2.  新建 feature_xxx 分支
3.  提交代码
4.  新建 Pull Request

#### 未来计划
* 完善多实例部署时 多Timeer同时扫描造成的资源消耗
* 增加更多请求方式
* 完善界面功能