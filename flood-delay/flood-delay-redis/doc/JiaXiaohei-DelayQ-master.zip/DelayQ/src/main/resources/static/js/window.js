function openSuccess(msg) {
    layer.open({
        icon: 1,
        offset: 'auto',
        content: msg,
        btn: '确定',
        btnAlign: 'c' //按钮居中
        ,
        shade: 0 //不显示遮罩
        ,
        yes: function() {
            layer.closeAll();
        }
    });
}

function openWarn(msg) {
    layer.open({
        icon: 0,
        offset: 'auto',
        content: msg,
        btn: '确定',
        btnAlign: 'c'        ,
        shade: 0         ,
        yes: function() {
            layer.closeAll();
        }
    });
}

function openError(msg) {
    layer.open({
        icon: 2,
        offset: 'auto',
        content: msg,
        btn: '确定',
        btnAlign: 'c'        ,
        shade: 0         ,
        yes: function() {
            layer.closeAll();
        }
    });
}

function openWindow(title ,url) {
          layer.open({
            type: 2
            ,title: title
            ,area: ['780px', '520px']
            ,shade: 0
            ,maxmin: true
            ,offset: 'auto'
            ,content: url
          });
}