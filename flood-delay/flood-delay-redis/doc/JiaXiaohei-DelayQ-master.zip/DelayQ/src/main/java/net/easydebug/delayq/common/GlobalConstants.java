/*
 * Copyright 2020. JiaXiaohei easyDebug.net
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *      http://www.apache.org/licenses/LICENSE-2.0
 *
 *  Unless required by applicable law or agreed to in writing, software
 *  distributed under the License is distributed on an "AS IS" BASIS,
 *  WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 *  See the License for the specific language governing permissions and
 *  limitations under the License.
 */

package net.easydebug.delayq.common;

public class GlobalConstants {

    public static final String STATUS_DELAY = "delay";

    public static final String STATUS_SUCCESS = "success";

    public static final String STATUS_ERROR = "error";

    public static final String STATUS_DELETED = "deleted";

    public static final String STATUS_RUNNER = "runner";

    public static String SEQUENCE_ID_KEY = DynamicConstants.REDIS_KEY_PREFIX + "SEQUENCE_ID";

    public static String DELAY_BUCKET_KEY = DynamicConstants.REDIS_KEY_PREFIX + "DELAY_BUCKET";

    public static String JOB_POLL_KEY = DynamicConstants.REDIS_KEY_PREFIX + "JOB_POLL";

}
