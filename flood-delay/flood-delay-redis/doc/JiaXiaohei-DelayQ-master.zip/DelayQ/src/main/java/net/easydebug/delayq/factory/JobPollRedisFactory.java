/*
 * Copyright 2020. JiaXiaohei easyDebug.net
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *      http://www.apache.org/licenses/LICENSE-2.0
 *
 *  Unless required by applicable law or agreed to in writing, software
 *  distributed under the License is distributed on an "AS IS" BASIS,
 *  WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 *  See the License for the specific language governing permissions and
 *  limitations under the License.
 */

package net.easydebug.delayq.factory;

import net.easydebug.delayq.common.DynamicConstants;
import net.easydebug.delayq.common.GlobalConstants;
import net.easydebug.delayq.entity.DelayQueueJob;
import net.easydebug.delayq.mapper.TbDelayqJobMapper;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.redis.core.HashOperations;
import org.springframework.data.redis.core.RedisTemplate;
import org.springframework.data.redis.core.ScanOptions;
import org.springframework.stereotype.Component;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

/**
 * Job Pool用来存放所有Job的元信息
 */
@Component
public class JobPollRedisFactory {

    private RedisTemplate redisTemplate;

    private HashOperations<String, Long, DelayQueueJob> jobPollHashOperations;

    @Autowired
    public JobPollRedisFactory(
            RedisTemplate redisTemplate) {
        this.redisTemplate = redisTemplate;
        this.jobPollHashOperations = redisTemplate.opsForHash();
    }

    public void put(DelayQueueJob delayQueueJob) {
        jobPollHashOperations.put(GlobalConstants.JOB_POLL_KEY, delayQueueJob.getId(), delayQueueJob);
    }

    public DelayQueueJob get(Long id) {
        return jobPollHashOperations.get(GlobalConstants.JOB_POLL_KEY, id);
    }

    public void delete(Long id) {
        jobPollHashOperations.delete(GlobalConstants.JOB_POLL_KEY, id);
    }

}
