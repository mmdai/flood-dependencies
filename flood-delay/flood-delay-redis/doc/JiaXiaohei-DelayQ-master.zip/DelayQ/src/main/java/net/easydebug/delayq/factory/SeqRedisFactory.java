/*
 * Copyright 2020. JiaXiaohei easyDebug.net
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *      http://www.apache.org/licenses/LICENSE-2.0
 *
 *  Unless required by applicable law or agreed to in writing, software
 *  distributed under the License is distributed on an "AS IS" BASIS,
 *  WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 *  See the License for the specific language governing permissions and
 *  limitations under the License.
 */

package net.easydebug.delayq.factory;

import net.easydebug.delayq.common.DynamicConstants;
import net.easydebug.delayq.common.GlobalConstants;
import net.easydebug.delayq.util.DateUtil;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.redis.core.RedisTemplate;
import org.springframework.data.redis.support.atomic.RedisAtomicLong;
import org.springframework.stereotype.Component;

import java.text.DecimalFormat;
import java.util.Date;
import java.util.concurrent.TimeUnit;

/**
 * 全局唯一ID生成类
 */
@Component
public class SeqRedisFactory {


    private static final int DELAY_QUEUE_SEQUENCE_ID_EXPIRE_MINUTES = 5;

    private RedisTemplate redisTemplate;

    @Autowired
    public SeqRedisFactory(RedisTemplate redisTemplate) {
        this.redisTemplate = redisTemplate;
    }

    public Long generateSeq() {
        String nowDatetimeString = DateUtil.date2String(new Date(), "yyyyMMddHHmmss");

        RedisAtomicLong redisAtomicLong = new RedisAtomicLong(GlobalConstants.SEQUENCE_ID_KEY + ":" + nowDatetimeString, redisTemplate.getConnectionFactory());
        Long increment = redisAtomicLong.incrementAndGet();
        if (increment.longValue() == 1) {
            redisAtomicLong.expire(DELAY_QUEUE_SEQUENCE_ID_EXPIRE_MINUTES, TimeUnit.MINUTES);
        }
        DecimalFormat decimalFormat = new DecimalFormat("0000");
        return Long.parseLong(nowDatetimeString + decimalFormat.format(redisAtomicLong));
    }

}
