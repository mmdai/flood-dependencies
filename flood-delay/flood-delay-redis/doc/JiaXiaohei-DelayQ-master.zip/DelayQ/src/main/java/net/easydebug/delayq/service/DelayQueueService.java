/*
 * Copyright 2020. JiaXiaohei easyDebug.net
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *      http://www.apache.org/licenses/LICENSE-2.0
 *
 *  Unless required by applicable law or agreed to in writing, software
 *  distributed under the License is distributed on an "AS IS" BASIS,
 *  WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 *  See the License for the specific language governing permissions and
 *  limitations under the License.
 */

package net.easydebug.delayq.service;

import net.easydebug.delayq.common.GlobalConstants;
import net.easydebug.delayq.entity.DelayQueueJob;
import net.easydebug.delayq.factory.DelayBucketRedisFactory;
import net.easydebug.delayq.factory.JobPollRedisFactory;
import net.easydebug.delayq.factory.SeqRedisFactory;
import net.easydebug.delayq.mapper.TbDelayqJobMapper;
import net.easydebug.delayq.util.DateUtil;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

@Service
public class DelayQueueService {

    private SeqRedisFactory seqRedisFactory;

    private DelayBucketRedisFactory delayBucket;

    private JobPollRedisFactory jobPoll;

    private TbDelayqJobMapper tbDelayqJobMapper;

    @Autowired
    public DelayQueueService(
            SeqRedisFactory seqRedisFactory,
            DelayBucketRedisFactory delayBucket,
            JobPollRedisFactory jobPoll,
            TbDelayqJobMapper tbDelayqJobMapper) {
        this.seqRedisFactory = seqRedisFactory;
        this.delayBucket = delayBucket;
        this.jobPoll = jobPoll;
        this.tbDelayqJobMapper = tbDelayqJobMapper;
    }

    public Long add(DelayQueueJob delayQueueJob) {

        Long seqId = seqRedisFactory.generateSeq();
        Date nowDate = new Date();

        delayQueueJob.setId(seqId);
        delayQueueJob.setCreateTime(DateUtil.date2timestamp(nowDate));
        delayQueueJob.setExecutionTime(getDelayQueueJobScore(nowDate, delayQueueJob.getDelay()));

        jobPoll.put(delayQueueJob);
        delayBucket.add(delayQueueJob);
        tbDelayqJobMapper.insert(delayQueueJob);

        return seqId;
    }

    public DelayQueueJob get(Long id) {
        DelayQueueJob delayQueueJob = jobPoll.get(id);
        if (null == delayQueueJob) {
            Map<String, Object> param = new HashMap<>();
            param.put("id", id);
            delayQueueJob = tbDelayqJobMapper.get(param);
        }
        return delayQueueJob;
    }

    public void del(Long id) {
        DelayQueueJob delayQueueJob = jobPoll.get(id);
        delayQueueJob.setStatus(GlobalConstants.STATUS_DELETED);

        jobPoll.put(delayQueueJob);
        delayBucket.del(id);

        Map<String, Object> param = new HashMap<>();
        param.put("id", id);
        tbDelayqJobMapper.delete(param);
    }

    public List<DelayQueueJob> list(Map<String, Object> param) {
        return tbDelayqJobMapper.list(param);
    }

    private static Long getDelayQueueJobScore(Date date, int delay) {
        return DateUtil.date2timestamp(DateUtil.addSecond(date, delay));
    }

}
