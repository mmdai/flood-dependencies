/*
 * Copyright 2020. JiaXiaohei easyDebug.net
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *      http://www.apache.org/licenses/LICENSE-2.0
 *
 *  Unless required by applicable law or agreed to in writing, software
 *  distributed under the License is distributed on an "AS IS" BASIS,
 *  WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 *  See the License for the specific language governing permissions and
 *  limitations under the License.
 */

package net.easydebug.delayq.factory;

import net.easydebug.delayq.common.DynamicConstants;
import net.easydebug.delayq.common.GlobalConstants;
import net.easydebug.delayq.entity.DelayQueueJob;
import net.easydebug.delayq.util.DateUtil;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.redis.core.RedisTemplate;
import org.springframework.data.redis.core.ZSetOperations;
import org.springframework.stereotype.Component;

import java.util.Date;
import java.util.Set;

/**
 * Delay Bucket是一个有序队列
 */
@Component
public class DelayBucketRedisFactory {

    private RedisTemplate redisTemplate;

    private ZSetOperations<String, Long> delayBucketZSetOperations;

    @Autowired
    public DelayBucketRedisFactory(RedisTemplate redisTemplate) {
        this.redisTemplate = redisTemplate;
        this.delayBucketZSetOperations = redisTemplate.opsForZSet();
    }

    public void add(DelayQueueJob delayQueueJob) {
        delayBucketZSetOperations.add(getDelayBucketKey(delayQueueJob.getId()), delayQueueJob.getId(), delayQueueJob.getExecutionTime());
    }

    /**
     * 获取Scores[时间戳]最小[最近]的JobId & 时间戳
     *
     * @param delayBucketRedisKey
     * @return
     */
    public Long[] getSoonJobId(String delayBucketRedisKey) {

//        Set<ZSetOperations.TypedTuple<Long>> rangeWithScores =
//                delayBucketZSetOperations.rangeWithScores(delayBucketRedisKey, 0, 0);
//        Iterator<ZSetOperations.TypedTuple<Long>> iterator = rangeWithScores.iterator();
//        while (iterator.hasNext()) {
//            ZSetOperations.TypedTuple<Long> typedTuple = iterator.next();
//            System.out.println("key:" + delayBucketRedisKey + " value:" + typedTuple.getValue() + " score:" + typedTuple.getScore().longValue());
//        }

        Set<ZSetOperations.TypedTuple<Long>> soonDelayQueueJobSet =
                delayBucketZSetOperations.rangeWithScores(delayBucketRedisKey, 0, 0);
        if (!soonDelayQueueJobSet.isEmpty()) {
            ZSetOperations.TypedTuple<Long> firstZSetOperations = soonDelayQueueJobSet.iterator().next();
            return new Long[]{firstZSetOperations.getValue(), firstZSetOperations.getScore().longValue()};
        } else {
            return null;
        }

    }

    public void del(Long id) {
        delayBucketZSetOperations.remove(getDelayBucketKey(id), id);
    }

    private static String getDelayBucketKey(Long id) {
        return GlobalConstants.DELAY_BUCKET_KEY + ":" + id.toString().charAt(13);
    }

}
