/*
 * Copyright 2020. JiaXiaohei easyDebug.net
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *      http://www.apache.org/licenses/LICENSE-2.0
 *
 *  Unless required by applicable law or agreed to in writing, software
 *  distributed under the License is distributed on an "AS IS" BASIS,
 *  WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 *  See the License for the specific language governing permissions and
 *  limitations under the License.
 */

package net.easydebug.delayq.thread;

import net.easydebug.delayq.common.DynamicConstants;
import net.easydebug.delayq.common.GlobalConstants;
import net.easydebug.delayq.entity.DelayQueueJob;
import net.easydebug.delayq.factory.DelayBucketRedisFactory;
import net.easydebug.delayq.factory.JobPollRedisFactory;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.scheduling.annotation.Async;
import org.springframework.stereotype.Component;

@Component
public class TimerThread {

    private static final Logger logger = LoggerFactory.getLogger(TimerThread.class);

    private DelayBucketRedisFactory delayBucketRedisFactory;

    private JobPollRedisFactory jobPollRedisFactory;

    private RunnerThread runnerThread;


    @Autowired
    public TimerThread(
            DelayBucketRedisFactory delayBucketRedisFactory,
            JobPollRedisFactory jobPollRedisFactory,
            RunnerThread runnerThread
    ) {
        this.delayBucketRedisFactory = delayBucketRedisFactory;
        this.jobPollRedisFactory = jobPollRedisFactory;
        this.runnerThread = runnerThread;
    }

    @Async("timmerThreadPoolTaskExecutor")
    public void run(int threadId) throws InterruptedException {

        String delayBucketRedisKey = GlobalConstants.DELAY_BUCKET_KEY + ":" + threadId;
        for (; ; ) {

            Long[] soonJobId = delayBucketRedisFactory.getSoonJobId(delayBucketRedisKey);

            if (soonJobId == null) {
                sleep();
                continue;
            }

            if (soonJobId[1] > System.currentTimeMillis()) {
                sleep();
                continue;
            }

            DelayQueueJob delayQueueJob = jobPollRedisFactory.get(soonJobId[0]);
            if (null == delayQueueJob) {
                delayBucketRedisFactory.del(delayQueueJob.getId());
                continue;
            }

            if (GlobalConstants.STATUS_DELAY.equals(delayQueueJob.getStatus())) {
                delayBucketRedisFactory.del(delayQueueJob.getId());
                runnerThread.run(delayQueueJob);
            }

        }
    }

    private void sleep() throws InterruptedException {
        Thread.sleep(999);
    }

}