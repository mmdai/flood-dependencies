/*
 * Copyright 2020. JiaXiaohei easyDebug.net
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *      http://www.apache.org/licenses/LICENSE-2.0
 *
 *  Unless required by applicable law or agreed to in writing, software
 *  distributed under the License is distributed on an "AS IS" BASIS,
 *  WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 *  See the License for the specific language governing permissions and
 *  limitations under the License.
 */

package net.easydebug.delayq.thread;

import net.easydebug.delayq.common.GlobalConstants;
import net.easydebug.delayq.entity.DelayQueueJob;
import net.easydebug.delayq.factory.JobPollRedisFactory;
import net.easydebug.delayq.mapper.TbDelayqJobMapper;
import net.easydebug.delayq.task.HttpPostTask;
import net.easydebug.delayq.task.PrintTask;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.scheduling.annotation.Async;
import org.springframework.stereotype.Component;

@Component
public class RunnerThread {

    private static final Logger logger = LoggerFactory.getLogger(RunnerThread.class);

    private JobPollRedisFactory jobPollRedisFactory;

    private TbDelayqJobMapper tbDelayqJobMapper;

    @Autowired
    public RunnerThread(
            JobPollRedisFactory jobPollRedisFactory,
            TbDelayqJobMapper tbDelayqJobMapper
    ) {
        this.jobPollRedisFactory = jobPollRedisFactory;
        this.tbDelayqJobMapper = tbDelayqJobMapper;
    }

    @Async("runnerThreadPoolTaskExecutor")
    public void run(DelayQueueJob delayQueueJob) {

        delayQueueJob.setStatus(GlobalConstants.STATUS_RUNNER);
        jobPollRedisFactory.put(delayQueueJob);
        tbDelayqJobMapper.update(delayQueueJob);

        Boolean taskResult = false;
        switch (delayQueueJob.getTopic()) {
            case "PrintTask":
                taskResult = new PrintTask().run(delayQueueJob.getId(), delayQueueJob.getBody());
                break;
            case "HttpPostTask":
                taskResult = new HttpPostTask().run(delayQueueJob.getId(), delayQueueJob.getBody());
                break;
        }

        if (taskResult) {
            delayQueueJob.setStatus(GlobalConstants.STATUS_SUCCESS);
        } else {
            delayQueueJob.setStatus(GlobalConstants.STATUS_ERROR);
        }

        jobPollRedisFactory.put(delayQueueJob);
        tbDelayqJobMapper.update(delayQueueJob);

    }

}