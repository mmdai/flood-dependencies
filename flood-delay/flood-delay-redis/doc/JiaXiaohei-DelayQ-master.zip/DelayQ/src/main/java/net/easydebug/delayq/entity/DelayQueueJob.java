/*
 * Copyright 2020. JiaXiaohei easyDebug.net
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *      http://www.apache.org/licenses/LICENSE-2.0
 *
 *  Unless required by applicable law or agreed to in writing, software
 *  distributed under the License is distributed on an "AS IS" BASIS,
 *  WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 *  See the License for the specific language governing permissions and
 *  limitations under the License.
 */

package net.easydebug.delayq.entity;

import com.alibaba.fastjson.annotation.JSONField;
import com.alibaba.fastjson.serializer.SimpleDateFormatSerializer;
import com.alibaba.fastjson.serializer.ToStringSerializer;
import net.easydebug.delayq.config.TimestampToStringSerializer;

import java.io.Serializable;

public class DelayQueueJob implements Serializable {

    @JSONField(serializeUsing = ToStringSerializer.class)
    private Long id;

    private String topic;

    private int delay;

    private int ttr;

    private String body;

    private String status;

    @JSONField(serializeUsing = TimestampToStringSerializer.class)
    private Long executionTime;

    @JSONField(serializeUsing = TimestampToStringSerializer.class)
    private Long createTime;

    public DelayQueueJob() {
    }

    public DelayQueueJob(Long id, String topic, int delay, int ttr, String body, String status, Long executionTime, Long createTime) {
        this.id = id;
        this.topic = topic;
        this.delay = delay;
        this.ttr = ttr;
        this.body = body;
        this.status = status;
        this.executionTime = executionTime;
        this.createTime = createTime;
    }

    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public String getTopic() {
        return topic;
    }

    public void setTopic(String topic) {
        this.topic = topic;
    }

    public int getDelay() {
        return delay;
    }

    public void setDelay(int delay) {
        this.delay = delay;
    }

    public int getTtr() {
        return ttr;
    }

    public void setTtr(int ttr) {
        this.ttr = ttr;
    }

    public String getBody() {
        return body;
    }

    public void setBody(String body) {
        this.body = body;
    }

    public String getStatus() {
        return status;
    }

    public void setStatus(String status) {
        this.status = status;
    }

    public Long getExecutionTime() {
        return executionTime;
    }

    public void setExecutionTime(Long executionTime) {
        this.executionTime = executionTime;
    }

    public Long getCreateTime() {
        return createTime;
    }

    public void setCreateTime(Long createTime) {
        this.createTime = createTime;
    }

//    @Override
//    public String toString() {
//        return JSON.toJSONString(this, new SerializerFeature[]{
//                SerializerFeature.WriteMapNullValue,
//                SerializerFeature.WriteNullListAsEmpty,
//                SerializerFeature.WriteNullStringAsEmpty,
//                SerializerFeature.WriteNullNumberAsZero,
//                SerializerFeature.WriteNullBooleanAsFalse,
//                SerializerFeature.UseISO8601DateFormat});
//    }

}
