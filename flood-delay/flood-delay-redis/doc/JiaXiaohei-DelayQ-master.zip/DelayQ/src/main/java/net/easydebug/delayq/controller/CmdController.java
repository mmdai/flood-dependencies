/*
 * Copyright 2020. JiaXiaohei easyDebug.net
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *      http://www.apache.org/licenses/LICENSE-2.0
 *
 *  Unless required by applicable law or agreed to in writing, software
 *  distributed under the License is distributed on an "AS IS" BASIS,
 *  WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 *  See the License for the specific language governing permissions and
 *  limitations under the License.
 */

package net.easydebug.delayq.controller;

import io.swagger.annotations.Api;
import io.swagger.annotations.ApiImplicitParam;
import io.swagger.annotations.ApiImplicitParams;
import io.swagger.annotations.ApiOperation;
import net.easydebug.delayq.common.GlobalConstants;
import net.easydebug.delayq.entity.DelayQueueJob;
import net.easydebug.delayq.entity.Response;
import net.easydebug.delayq.factory.SeqRedisFactory;
import net.easydebug.delayq.service.DelayQueueService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

@Api(tags = "指令接口")
@RestController("cmdController")
public class CmdController {

    private DelayQueueService delayQueueService;

    @Autowired
    public CmdController(
            DelayQueueService delayQueueService
    ) {
        this.delayQueueService = delayQueueService;
    }

    @ApiOperation(value = "添加", response = Response.class, notes = "添加Job")
    @ApiImplicitParams({
            @ApiImplicitParam(name = "topic", value = "Job类型", paramType = "query", required = true, dataType = "String"),
            @ApiImplicitParam(name = "delay", value = "Job需要延迟的时间(s)", paramType = "query", required = true, dataType = "int", example = "60"),
            @ApiImplicitParam(name = "ttr", value = "Job执行超时时间(s)", paramType = "query", required = true, dataType = "int", example = "5"),
            @ApiImplicitParam(name = "body", value = "Job的内容", paramType = "body", required = true, dataType = "String")
    })
    @RequestMapping(value = "add", method = {RequestMethod.POST})
    public Response<Long> add(
            @RequestParam(name = "topic") String topic,
            @RequestParam(name = "delay") int delay,
            @RequestParam(name = "ttr") int ttr,
            @RequestBody(required = false) String body) {

        Response<Long> response = new Response();

        try {
            DelayQueueJob delayQueueJob = new DelayQueueJob();
            delayQueueJob.setTopic(topic);
            delayQueueJob.setDelay(delay);
            delayQueueJob.setTtr(ttr);
            delayQueueJob.setBody(body);
            delayQueueJob.setStatus(GlobalConstants.STATUS_DELAY);
            Long id = delayQueueService.add(delayQueueJob);
            response.setData(id);
        } catch (Exception e) {
            response.setCode(0);
            response.setMsg(e.getClass() + " " + e.getLocalizedMessage());
        }

        return response;
    }

    @ApiOperation(value = "查询", response = Response.class, notes = "查询Job")
    @ApiImplicitParams({
            @ApiImplicitParam(name = "id", value = "Job ID", paramType = "query", required = true, dataType = "Long"),
    })
    @RequestMapping(value = "info", method = {RequestMethod.POST})
    public Response<DelayQueueJob> info(
            @RequestParam(name = "id") Long id) {
        Response<DelayQueueJob> response = new Response();

        try {
            response.setData(delayQueueService.get(id));
        } catch (Exception e) {
            response.setCode(0);
            response.setMsg(e.getClass() + " " + e.getLocalizedMessage());
        }

        return response;
    }

    @ApiOperation(value = "删除", response = Response.class, notes = "删除Job")
    @ApiImplicitParams({
            @ApiImplicitParam(name = "id", value = "Job ID", paramType = "query", required = true, dataType = "Long"),
    })
    @RequestMapping(value = "del", method = {RequestMethod.POST})
    public Response del(
            @RequestParam(name = "id") Long id) {
        Response response = new Response();

        DelayQueueJob delayQueueJob = delayQueueService.get(id);

        if (null == delayQueueJob) {
            response.setCode(0);
            response.setMsg("查无此任务");
            return response;
        }

        if (!delayQueueJob.getStatus().equals(GlobalConstants.STATUS_DELAY)) {
            response.setCode(0);
            response.setMsg("任务状态为:" + delayQueueJob.getStatus() + " 无法删除");
            return response;
        }

        try {
            delayQueueService.del(id);
        } catch (Exception e) {
            response.setCode(0);
            response.setMsg(e.getClass() + " " + e.getLocalizedMessage());
        }

        return response;
    }

}
