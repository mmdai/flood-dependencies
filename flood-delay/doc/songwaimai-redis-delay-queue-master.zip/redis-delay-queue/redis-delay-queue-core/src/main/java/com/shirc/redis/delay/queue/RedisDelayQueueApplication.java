package com.shirc.redis.delay.queue;


public class RedisDelayQueueApplication {

    public static void main(String[] args) {
    }

}
