package com.shirc.redis.delay.queue.common;

/**
 * @Description
 * @Author shirenchuang
 * @Date 2019/7/31 10:08 AM
 **/
public class DelayQueueException extends RuntimeException {


    public DelayQueueException(String message) {
        super(message);
    }
}
