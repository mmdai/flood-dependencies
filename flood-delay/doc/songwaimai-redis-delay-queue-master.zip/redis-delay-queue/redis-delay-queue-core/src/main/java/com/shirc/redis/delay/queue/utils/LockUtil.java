package com.shirc.redis.delay.queue.utils;

/**
 * @Description  对象锁
 * @Author shirenchuang
 * @Date 2019/7/31 11:00 AM
 **/
public class LockUtil {

    /**用于synchronized加锁**/
    public static Object lock =  new Object();
}
