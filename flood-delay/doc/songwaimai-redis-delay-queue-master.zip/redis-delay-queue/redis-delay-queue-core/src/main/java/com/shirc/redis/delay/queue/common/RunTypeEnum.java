package com.shirc.redis.delay.queue.common;

/**
 * @Description 同步调用还是异步调用
 * @Author shirenchuang
 * @Date 2019/8/7 10:32 AM
 **/
public enum  RunTypeEnum {

    /**同步**/
    SYNC,
    /**异步**/
    ASYNC;

}
